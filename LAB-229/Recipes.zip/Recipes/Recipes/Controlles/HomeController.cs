﻿using Microsoft.AspNetCore.Mvc;

namespace Recipes.Controlles
{
  public class HomeController : Controller
  {
    // GET
    public ViewResult Index()
    {
      return View();
    }
    public ViewResult Data()
    {
      return View();
    }
    public ViewResult Display()
    {
      return View();
    }
    public ViewResult Insert()
    {
      return View();
    }
    public ViewResult User()
    {
      return View();
    }
  }
}