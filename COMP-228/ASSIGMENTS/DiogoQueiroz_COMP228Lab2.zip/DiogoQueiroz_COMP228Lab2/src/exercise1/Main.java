package exercise1;

public class Main {

    public static void main(String[] args) {
        // Instantiate the QuestionCollection Object
        QuestionsCollection test = new QuestionsCollection();
        test.InputAnswer(); // Execute the InputAnswer and simulate the questions
    }
}
